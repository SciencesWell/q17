$(function () {

    // Header Scroll
    $(window).scroll(function () {
        if ($(window).scrollTop() >= 60) {
            $("header").addClass("fixed-header");
        } else {
            $("header").removeClass("fixed-header");
        }
    });



    // Tooltip
    const tooltipTriggerList = Array.from(
        document.querySelectorAll('[data-bs-toggle="tooltip"]')
    );
    tooltipTriggerList.forEach((tooltipTriggerEl) => {
        new bootstrap.Tooltip(tooltipTriggerEl);
    });


    // Count
    $('.count').each(function () {
        $(this).prop('Counter', 0).animate({
            Counter: $(this).text()
        }, {
            duration: 1000,
            easing: 'swing',
            step: function (now) {
                $(this).text(Math.ceil(now));
            }
        });
    });


    // ScrollToTop
    function scrollToTop() {
        window.scrollTo({
            top: 0,
            behavior: 'smooth'
        });
    }

    const btn = document.getElementById("scrollToTopBtn");
    if (btn) {
        btn.addEventListener("click", scrollToTop);
    }

    function updateScrollBtn() {
        const btn = document.getElementById("scrollToTopBtn");
        if (!btn) return;
        if (document.documentElement.scrollTop > 120 || document.body.scrollTop > 120) {
            btn.classList.add("is-visible");
            btn.style.display = "flex";
        } else {
            btn.classList.remove("is-visible");
            btn.style.display = "none";
        }
    }
    window.addEventListener("scroll", updateScrollBtn, { passive: true });
    updateScrollBtn();
    (function(){
        const btn = document.getElementById("scrollToTopBtn");
        if (btn) {
            btn.addEventListener("click", function(e){
                e.preventDefault();
                window.scrollTo({ top: 0, behavior: "smooth" });
            });
        }
    })();


    // Aos
    if (typeof AOS !== 'undefined') {
        AOS.init({
            once: true,
            duration: 500,
            offset: 40,
            easing: 'ease-out',
        });
    }


    // Scroll
    const sections = document.querySelectorAll("section[id]");

    window.addEventListener("scroll", navHighlighter);

    function navHighlighter() {

        let scrollY = window.pageYOffset;

        sections.forEach(current => {
            const sectionHeight = current.offsetHeight;
            const sectionTop = current.offsetTop - 100;
            const sectionId = current.getAttribute("id");

            const link = document.querySelector(".navbar-collapse a[href*=" + sectionId + "]");
            if (!link) return;

            if (
                scrollY > sectionTop &&
                scrollY <= sectionTop + sectionHeight
            ) {
                link.classList.add("active");
            } else {
                link.classList.remove("active");
            }
        });
    }

    // ===== Slot machine effect =====
    (function initSlot() {
        const track = document.getElementById('slotTrack');
        if (!track) return;
        const items = track.querySelectorAll('.slot-item');
        const count = items.length - 1; // last is duplicate of first
        let index = 0;
        let itemHeight = items[0].offsetHeight;
        if (!itemHeight || itemHeight < 10) {
            itemHeight = parseFloat(getComputedStyle(document.querySelector('h1')).fontSize) * 1.15 || 48;
        }

        function spin() {
            index = (index + 1) % count;
            if (index === 0) {
                track.style.transition = 'transform 0.6s cubic-bezier(0.23, 1, 0.32, 1)';
                track.style.transform = 'translateY(-' + (count * itemHeight) + 'px)';
                setTimeout(function () {
                    track.style.transition = 'none';
                    track.style.transform = 'translateY(0)';
                }, 650);
            } else {
                track.style.transition = 'transform 0.6s cubic-bezier(0.23, 1, 0.32, 1)';
                track.style.transform = 'translateY(-' + (index * itemHeight) + 'px)';
            }
        }
        const viewport = track.parentElement;
        if (viewport) {
            viewport.style.height = itemHeight + 'px';
        }
        setInterval(spin, 2500);
    })();

    // ===== Tariff auto-fill on contact page =====
    (function fillTariff() {
        const params = new URLSearchParams(window.location.search);
        const srcEl = document.getElementById('leadSource');
        if (srcEl) srcEl.value = params.get('service') ? 'Услуга: ' + params.get('service') : (params.get('tariff') ? 'Тариф: ' + params.get('tariff') : '');
        const service = params.get('service');
        if (service) {
            const map = { 'Внедрение amoCRM': 'Внедрение amoCRM', 'Телефония Телфин': 'Телефония Телфин', 'Чат-боты SmartBot': 'Чат-бот SmartBot', 'Автоматизация продаж': 'Комплексное внедрение' };
            const sel = document.getElementById('interested');
            if (sel && map[service]) sel.value = map[service];
            const m0 = document.getElementById('message');
            if (m0 && !m0.value) { m0.value = 'Хочу записаться на бесплатный аудит: ' + service + '. '; const cc0 = document.getElementById('charCount'); if (cc0) cc0.textContent = m0.value.length; }
        }
        const tariff = params.get('tariff');
        if (!tariff) return;
        const msg = document.getElementById('message');
        if (msg && !msg.value) {
            msg.value = 'Интересует тариф «' + tariff + '». ';
        }
    })();

    // ===== Form validation + success popup =====
    const form = document.getElementById('contactForm');
    const successModal = document.getElementById('successModal');
    const successClose = document.getElementById('successModalClose');

    function showSuccessModal() {
        if (successModal) {
            successModal.classList.add('show');
            document.body.style.overflow = 'hidden';
        }
    }
    function hideSuccessModal() {
        if (successModal) {
            successModal.classList.remove('show');
            document.body.style.overflow = '';
        }
    }
    if (successClose) {
        successClose.addEventListener('click', hideSuccessModal);
    }
    if (successModal) {
        successModal.addEventListener('click', function (e) {
            if (e.target === successModal) hideSuccessModal();
        });
    }

    if (form) {
        form.addEventListener('submit', function (e) {
            e.preventDefault();
            e.stopPropagation();
            form.classList.add('was-validated');
            if (!form.checkValidity()) {
                return false;
            }
            // Collect the data first (before the form is reset)
            const action = form.getAttribute('action');
            const formData = new FormData(form);
            // Close the on-screen keyboard (phones) so the popup is not delayed by viewport resize
            try {
                if (document.activeElement && typeof document.activeElement.blur === 'function') {
                    document.activeElement.blur();
                }
            } catch (err) {}
            // Show the popup right away - it paints before any network/reset work
            showSuccessModal();
            // Heavy work goes after the first paint
            window.requestAnimationFrame(function () {
                setTimeout(function () {
                    try {
                        fetch(action, {
                            method: 'POST',
                            body: formData,
                            headers: { 'Accept': 'application/json' },
                            keepalive: true
                        }).catch(function () {});
                    } catch (err) {}
                    form.reset();
                    form.classList.remove('was-validated');
                    var cc = document.getElementById('charCount');
                    if (cc) cc.textContent = '0';
                }, 0);
            });
            return false;
        });
    }


    // Cookie banner (single instance)
    (function () {
        if (document.getElementById('cookieBanner')) return;
        try {
            if (localStorage.getItem('q17_cookies_ok') === '1') return;
        } catch (e) {}
        var bar = document.createElement('div');
        bar.id = 'cookieBanner';
        bar.className = 'cookie-banner is-visible';
        bar.setAttribute('role', 'dialog');
        bar.innerHTML = '<p>Мы используем cookie и технические данные для работы сайта. Подробнее — в <a href="cookie-policy.html">Политике использования cookie</a> и <a href="privacy-policy.html">Политике обработки персональных данных</a>.</p><button type="button" class="btn btn-dark btn-sm" id="cookieAccept">Принять</button>';
        document.body.appendChild(bar);
        bar.querySelector('#cookieAccept').onclick = function (e) {
            e.preventDefault();
            try { localStorage.setItem('q17_cookies_ok', '1'); } catch (err) {}
            bar.remove();
        };
    })();

});
